How to Play!
W key - move forward
A key - turn left
D key - turn right
Arrow keys control the camera, but not necessary for gameplay
Space jumps

//For unstable gameplay//
Q key turns on gravity
	-- Like I mentioned in my presentation, this is quite unstable, however, the level no longer shakes. The character ends up being set into the block so xz movement becomes slightly difficult. The character will fall off the ledge though. The main issue with this is that the character cannot jump off of the platform.


U key turns on flocking. The flocking behavior is supposed to be set up so that when turned on, the goal node of the flock is set to the position of the character. The flock will continuously flock towards the character and if it reaches the character before the player reaches the goal, reset. 
//

Notes/Issues/Bugs

**There is a material that I put in the Examples.materials file so that the floor texture is invisible. I have included the file in this directory.

**I also changed the coordinates of the camera in sdkcameraman. You can either change the code to what I have below or move the camera around to your liking, it does not matter since it does not affect gameplay. 
	--in SdkCameraMan.h, in the setTarget function, change setYawPitchDist to:
		setYawPitchDist(Ogre::Degree(180), Ogre::Degree(15), 20);

**With gravity turned off, platforming behavior works as it should, except for when you walk off the ledge. If you jump while not above a platform you will fall and be reset.

**To change levels, you actually need to hardcode the level in (that code is in the top of the level loading code ie "level001.txt or 002 or 003).

**Be careful when trying to move around while jumping or in the air (Sinbad thinks its funny to try to do some tricks). Yes, that does mean that Sinbad cannot actually jump OVER gaps...woops.

**I would advise against turning while running forward, sometimes it gets a little jittery.



/*Author's Note*\
Thanks for a great semester! I really enjoyed the class and learned a lot, and as buggy and slightly unstable as this game can be at times, I definitely think that shows. Have fun with the prototype, but be patient with it, I definitely bit off more than I could chew for the time alloted, but I gave it my best attempt. :)
