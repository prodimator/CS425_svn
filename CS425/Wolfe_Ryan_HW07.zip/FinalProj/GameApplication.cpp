#include "GameApplication.h"
#include "Grid.h" // Lecture 5
#include <fstream>
#include <sstream>
#include <map> 
#define _USE_MATH_DEFINES
#include <math.h>

using namespace std;
//-------------------------------------------------------------------------------------
GameApplication::GameApplication(void)
{
	agent = NULL; // Init member data
}
//-------------------------------------------------------------------------------------
GameApplication::~GameApplication(void)
{
	if (agent != NULL){  // clean up memory
		delete agent; 
		//delete Ggrid;
	}
}

//-------------------------------------------------------------------------------------
void GameApplication::createScene(void)
{
    loadEnv();
	setupEnv();
	loadObjects();
	loadCharacters();
}
//////////////////////////////////////////////////////////////////
// Lecture 5: Returns a unique name for loaded objects and agents
std::string getNewName() // return a unique name 
{
	static int count = 0;	// keep counting the number of objects

	std::string s;
	std::stringstream out;	// a stream for outputing to a string
	out << count++;			// make the current count into a string
	s = out.str();

	return "object_" + s;	// append the current count onto the string
}

// Lecture 5: Load level from file!
void // Load the buildings or ground plane, etc
GameApplication::loadEnv()
{
	using namespace Ogre;	// use both namespaces
	using namespace std;

	class readEntity // need a structure for holding entities
	{
	public:
		string filename;
		float y;
		float scale;
		float orient;
		bool agent;
	};

	

	ifstream inputfile;		// Holds a pointer into the file

	string path = __FILE__; //gets the current cpp file's path with the cpp file
	path = path.substr(0,1+path.find_last_of('\\')); //removes filename to leave path
	path+= "level001.txt"; //if txt file is in the same directory as cpp file
	inputfile.open(path);

	//inputfile.open("D:/CS425-2012/Lecture 8/GameEngine-loadLevel/level001.txt"); // bad explicit path!!!
	if (!inputfile.is_open()) // oops. there was a problem opening the file
	{
		cout << "ERROR, FILE COULD NOT BE OPENED" << std::endl;	// Hmm. No output?
		return;
	}

	// the file is open
	int x,z;
	inputfile >> x >> z;	// read in the dimensions of the grid
	string matName;
	inputfile >> matName;	// read in the material name

	// create floor mesh using the dimension read
	MeshManager::getSingleton().createPlane("floor", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, 
		Plane(Vector3::UNIT_Y, 0), x*NODESIZE, z*NODESIZE, x, z, true, 1, x, z, Vector3::UNIT_Z);
	
	//create a floor entity, give it material, and place it at the origin
	Entity* floor = mSceneMgr->createEntity("Floor", "floor");
	floor->setMaterialName(matName);
	floor->setCastShadows(false);
	mSceneMgr->getRootSceneNode()->attachObject(floor);

	
	Grid Newgrid(mSceneMgr, z, x); // Set up the grid. z is rows, x is columns	
	//Grid grid(mSceneMgr,z,x);
	grid= Newgrid;
	grid.count=0;	//sets count to 0
	
	string buf;
	inputfile >> buf;	// Start looking for the Objects section
	while  (buf != "Objects")
		inputfile >> buf;
	if (buf != "Objects")	// Oops, the file must not be formated correctly
	{
		cout << "ERROR: Level file error" << endl;
		return;
	}

	// read in the objects
	readEntity *rent = new readEntity();	// hold info for one object
	std::map<string,readEntity*> objs;		// hold all object and agent types;
		//
	//while (!inputfile.eof() && buf !="Terrain"){
	//	inputfile >> buf;		// read in the char
	//	if (buf != "Terrain"){
	//		cout<<buf<<endl;
	//	}
	//}


	while (!inputfile.eof() && buf != "Characters") // read through until you find the Characters section
	{ 
		inputfile >> buf;			// read in the char
		if (buf != "Characters")
		{
			inputfile >> rent->filename >> rent->y >> rent->orient >> rent->scale;  // read the rest of the line
			rent->agent = false;		// these are objects
			objs[buf] = rent;			// store this object in the map
			rent = new readEntity();	// create a new instance to store the next object
		}

	}




	while  (buf != "Characters")	// get through any junk
		inputfile >> buf;
	
	// Read in the characters
	



	while (!inputfile.eof() && buf != "World") // Read through until the world section
	{
		inputfile >> buf;		// read in the char
		if (buf != "World")
		{
			inputfile >> rent->filename >> rent->y >> rent->scale; // read the rest of the line
			rent->agent = true;			// this is an agent
			objs[buf] = rent;			// store the agent in the map
			rent = new readEntity();	// create a new instance to store the next object
		}
	}


	

	delete rent; // we didn't need the last one

	// read through the placement map
	char c;
	for (int i = 0; i < z; i++)			// down (row)
		for (int j = 0; j < x; j++)		// across (column)
		{
			inputfile >> c;			// read one char at a time
			buf = c + '\0';			// convert char to string
			rent = objs[buf];		// find cooresponding object or agent
			if (rent != NULL)		// it might not be an agent or object
				if (rent->agent)	// if it is an agent...
				{
					// Use subclasses instead!
					agent = new Agent(this->mSceneMgr, getNewName(), rent->filename, rent->y, rent->scale);
					if (rent->filename=="sinbad.mesh"){
						playerList.push_back(agent);		//if its sinbad, add it to playerlist instead of agent list
						agent->orientation=0;
						
					}
					else{	
						agentList.push_back(agent);
					}
					agent->setPosition(grid.getPosition(i+1,j).x, rent->y, grid.getPosition(i+1,j).z);
					Ogre::Vector3 temp2(grid.getPosition(i+1,j).x, rent->y, grid.getPosition(i+1,j).z);			
					agent->origin= temp2;
					agent->pos = temp2;
					agent->x=grid.getPosition(i,j).x; agent->y= rent->y; agent->z= grid.getPosition(i,j).z;		//these two are basically the same thing but calling setPos creates problems.
					agent->current= grid.getNode(i,j);
					Ogre::Vector3 temp;
					temp[0]=0;temp[1]=0;temp[2]=0;				//set velocity to 0 vector
					agent->velocity=temp;
					agent->jumping=false;			//this just sets a bunch of junk to default settings
					agent->falling=true;
					agent->toggleGravity=false;

					//agent->gridPosx=grid.getPosition(i,j).x;
					//agent->gridPosy=grid.getPosition(i,j).y;
					

					// If we were using different characters, we'd have to deal with 
					// different animation clips. 
				}
				else	// Load objects
				{
					grid.loadObject(getNewName(), rent->filename, i, rent->y, j, rent->scale);
				}
			else // not an object or agent
			{
				if (c == 'w') // create a wall
				{
					Entity* ent = mSceneMgr->createEntity(getNewName(), Ogre::SceneManager::PT_CUBE);
					ent->setMaterialName("Examples/RustySteel");
					Ogre::SceneNode* mNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();				//sets up all the platforms
					mNode->attachObject(ent);
					mNode->scale(0.1f,0.1f,0.1f); // cube is 100 x 100
					Ogre::Quaternion q;
					Ogre::Vector3 vec(1,0,0);
					q.FromAngleAxis(Ogre::Radian((90*M_PI)/180), vec);			//rotates blocks to that they are laying down
					mNode->rotate(q);
					grid.getNode(i,j)->setOccupied();  // indicate that agents can't pass through
					mNode->setPosition(grid.getPosition(i,j).x, 0.0f, grid.getPosition(i,j).z);
					objList.push_back(ent);
				}
				else if (c == 'e')
				{
					ParticleSystem::setDefaultNonVisibleUpdateTimeout(5);  // set nonvisible timeout
					ParticleSystem* ps = mSceneMgr->createParticleSystem(getNewName(), "Examples/PurpleFountain");		//creates a particle system at coordinates of the goal
					Ogre::SceneNode* mNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
					mNode->attachObject(ps);
					mNode->setPosition(grid.getPosition(i-1,j).x, 0.0f, grid.getPosition(i-1,j).z);
					//goal.push_back(ps);

					Entity* gol= mSceneMgr->createEntity(getNewName(), Ogre::SceneManager::PT_CUBE);		//creates a small block as the goal entity, scales it so its small and then hides it
					gol->setMaterialName("Examples/RustySteel");											//if player intersects with block, got to goal!
					Ogre::SceneNode* boxNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
					boxNode->attachObject(gol);
					boxNode->setPosition(grid.getPosition(i-1,j).x, 5.0f, grid.getPosition(i-1,j).z);
					boxNode->scale(.025f, .025, .025);
					goal.push_back(gol);
					gol->setVisible(false);
					
				}
			}
		}

	//create a flock
	for (int i=0;i<3;i++){
		for (int j=0;j<3;j++){
			agent = new Agent(this->mSceneMgr, getNewName(), "sinbad.mesh", 5, .4);
			agentList.push_back(agent);
			agent->setPosition(grid.getPosition(i,j).x, 5, grid.getPosition(i,j).z);
			agent->x=grid.getPosition(i,j).x; agent->y= 5; agent->z= grid.getPosition(i,j).z;		//these two are basically the same thing but calling setPos creates problems.
			agent->current= grid.getNode(i,j);
			Ogre::Vector3 temp;
			temp[0]=0;temp[1]=0;temp[2]=0;				//set velocity to 0 vector
			agent->velocity=temp;
		}
	}
	
	// delete all of the readEntities in the objs map
	rent = objs["s"]; // just so we can see what is going on in memory (delete this later)
	
	std::map<string,readEntity*>::iterator it;
	for (it = objs.begin(); it != objs.end(); it++) // iterate through the map
	{
		delete (*it).second; // delete each readEntity
	}
	objs.clear(); // calls their destructors if there are any. (not good enough)
	
	inputfile.close();
	grid.printToFile(0); // see what the initial grid looks like.

	//set camera to characters
	std::list<Agent*>::iterator ag=playerList.begin();
	mCameraMan->setTarget((*ag)->getBody());
	(*ag)->getBody()->attachObject(mCamera);	//attach camera to sinbad node;

}

void // Set up lights, shadows, etc
GameApplication::setupEnv()
{
	using namespace Ogre;

	// set shadow properties
	mSceneMgr->setShadowTechnique(SHADOWTYPE_TEXTURE_MODULATIVE);
	mSceneMgr->setShadowColour(ColourValue(0.5, 0.5, 0.5));
	mSceneMgr->setShadowTextureSize(1024);
	mSceneMgr->setShadowTextureCount(1);

	// disable default camera control so the character can do its own 
	mCameraMan->setStyle(OgreBites::CS_FREELOOK); // CS_FREELOOK, CS_ORBIT, CS_MANUAL

	// use small amount of ambient lighting
	mSceneMgr->setAmbientLight(ColourValue(0.3f, 0.3f, 0.3f));

	// add a bright light above the scene
	Light* light = mSceneMgr->createLight();
	light->setType(Light::LT_POINT);
	light->setPosition(-10, 40, 20);
	light->setSpecularColour(ColourValue::White);

	mSceneMgr->setSkyBox(true, "Examples/SpaceSkyBox", 1000); // Lecture 4
}

void // Load other props or objects
GameApplication::loadObjects()
{
		//loading in from file now instead

}

void // Load actors, agents, characters
GameApplication::loadCharacters()
{
	// Lecture 5: now loading from file
	// agent = new Agent(this->mSceneMgr, "Sinbad", "Sinbad.mesh");
}



void
GameApplication::addTime(Ogre::Real deltaTime)
{
	///////////// handles constant keyboard inputs
	if (mKeyboard->isKeyDown(OIS::KC_W)){

		std::list<Agent*>::iterator it=playerList.begin();
		Ogre::Vector3 temp= (*it)->getPos();		//adds velocity to current position
		temp.z+=1;
		//(*it)->addWalk(temp);
		(*it)->forward();			//while w key is pressed, call forward method to move character forward
		//(*it)->forwa=true;
	}


	if (mKeyboard->isKeyDown(OIS::KC_A)){
		std::list<Agent*>::iterator it=playerList.begin();
		(*it)->turn(1);			//while held down, keep turning to the left
		//Ogre::Vector3 temp= (*it)->getPos();		//adds velocity to current position
		//temp.x+=10;
		//(*it)->addWalk(temp);
	}
	if (mKeyboard->isKeyDown(OIS::KC_S)){			//was going to implement moving backwards, didnt
		std::list<Agent*>::iterator it=playerList.begin();
		//Ogre::Vector3 temp= (*it)->getPos();		//adds velocity to current position
		//temp.z-=10;
		//(*it)->addWalk(temp);
	}
	if (mKeyboard->isKeyDown(OIS::KC_D)){			//while held down, turn right
		std::list<Agent*>::iterator it=playerList.begin();
		(*it)->turn(-1);
		//Ogre::Vector3 temp= (*it)->getPos();		//adds velocity to current position
		//temp.x-=10;
		//(*it)->addWalk(temp);
	}
	////////////////////////////////
	// Lecture 5: Iterate over the list of agents
	std::list<Agent*>::iterator iter;
	for (iter = agentList.begin(); iter != agentList.end(); iter++)
		if (*iter != NULL)
			(*iter)->update(deltaTime, objList, goal);

	for (iter = playerList.begin(); iter != playerList.end(); iter++)
		if (*iter != NULL)
			(*iter)->update(deltaTime, objList, goal);
}

bool		//for flocking
GameApplication::closeToGoal(list<Agent*> agentList, Ogre::Vector3 goal){
	// after each loop through the list of agents to calc velocities, this checks if the center of the flock is within a given radius of the goal point, if it is, it returns true
	Ogre::Vector3 center;
	center[0]=0;center[1]=0;center[2]=0;
	for (list<Agent*>::iterator it= agentList.begin(); it!=agentList.end(); it++){
		center=center+(*it)->getPos();			//adds positions to center
	}
	center=center/agentList.size();			//divides by size of agent list - 1
	if (sqrt(pow(center[0]-goal[0],2)+pow(center[2]-goal[2],2))<30){		//if distance from center to goal is < 30, return true
		return false;
	}

	else{	return true;	}



}


void		//for flocking
GameApplication::flockTo(std::list<Agent*> flockList, std::list<Agent*> playerList){
	int r;
	int c;
	//for (int j=0;j<12;j++){
		cout<<"Going to next point..."<<endl;
		list<Agent*>::iterator player= playerList.begin();
		r=(*player)->getBody()->getPosition().x;		//gets coordinates for the player node for the flock to flock to
		c=(*player)->getBody()->getPosition().z;
	
		Ogre::Vector3 goal= grid.getPosition(r,c);		//sets goal as coordinates of random points
		Ogre::Vector3 v1,v2,v3, v4;
		while (closeToGoal(flockList, goal)==true){		//while the center of flock is not within radius of goal
			for (list<Agent*>::iterator it= flockList.begin(); it!=flockList.end();++it){
				(*it)->setPosition((*it)->x, (*it)->y,(*it)->z);		//setPosition is called here because its doing funky stuff -- mentioned in README -- worked best this way

				v1=(*it)->sepVelocity(flockList);		//calculate separation velocity
				v2=(*it)->alignVel(flockList);			//calculates alignment velocity
				v3=(*it)->cohere(flockList);			//calculates cohere velocity
				v4=(*it)->goToGoal(flockList, goal);	//calculates path to goal velocity
				(*it)->velocity+=.45*v1+.55*v2+.25*v3+.75*v4;		//sums them with their weights -- a lot of guess and check so probably weights that will work better

				Ogre::Vector3 temp= (*it)->getPos()+(*it)->velocity;		//adds velocity to current position
				(*it)->addWalk(temp);
				(*it)->x=temp[0]; (*it)->z=temp[2];		//temp variables for position of agent to deal with setPosition bug
			}
		}
	//}

}

bool 
GameApplication::keyPressed( const OIS::KeyEvent &arg ) // Moved from BaseApplication
{

	/*if (arg.key== OIS::KC_W){
		Ogre::Vector3 vec(0,0,5);
		std::list<Agent*>::iterator it=playerList.begin();
		(*it)->forward();
	}*/

	if (arg.key == OIS::KC_SPACE){
		std::list<Agent*>::iterator it=playerList.begin();
		(*it)->jump(100);
		//(*it)->vert=true;
		//(*it)->jumping= true;
		/*(*it)->vel[0]=0;
		(*it)->vel[2]=0;
		(*it)->vel[1]=100*sin(90*(M_PI/180));*/
	}

    if (mTrayMgr->isDialogVisible()) return true;   // don't process any more keys if dialog is up

    if (arg.key == OIS::KC_F)   // toggle visibility of advanced frame stats
    {
        mTrayMgr->toggleAdvancedFrameStats();
    }
	if (arg.key == OIS::KC_U){
		flockTo(flockList, playerList);
	}
	if (arg.key == OIS::KC_Q){
		std::list<Agent*>::iterator it=playerList.begin();
		(*it)->toggleGravity=!(*it)->toggleGravity;
	}
    else if (arg.key == OIS::KC_G)   // toggle visibility of even rarer debugging details
    {
        if (mDetailsPanel->getTrayLocation() == OgreBites::TL_NONE)
        {
            mTrayMgr->moveWidgetToTray(mDetailsPanel, OgreBites::TL_TOPRIGHT, 0);
            mDetailsPanel->show();
        }
        else
        {
            mTrayMgr->removeWidgetFromTray(mDetailsPanel);
            mDetailsPanel->hide();
        }
    }
    else if (arg.key == OIS::KC_T)   // cycle polygon rendering mode
    {
        Ogre::String newVal;
        Ogre::TextureFilterOptions tfo;
        unsigned int aniso;

        switch (mDetailsPanel->getParamValue(9).asUTF8()[0])
        {
        case 'B':
            newVal = "Trilinear";
            tfo = Ogre::TFO_TRILINEAR;
            aniso = 1;
            break;
        case 'T':
            newVal = "Anisotropic";
            tfo = Ogre::TFO_ANISOTROPIC;
            aniso = 8;
            break;
        case 'A':
            newVal = "None";
            tfo = Ogre::TFO_NONE;
            aniso = 1;
            break;
        default:
            newVal = "Bilinear";
            tfo = Ogre::TFO_BILINEAR;
            aniso = 1;
        }

        Ogre::MaterialManager::getSingleton().setDefaultTextureFiltering(tfo);
        Ogre::MaterialManager::getSingleton().setDefaultAnisotropy(aniso);
        mDetailsPanel->setParamValue(9, newVal);
    }
    else if (arg.key == OIS::KC_R)   // cycle polygon rendering mode
    {
        Ogre::String newVal;
        Ogre::PolygonMode pm;

        switch (mCamera->getPolygonMode())
        {
        case Ogre::PM_SOLID:
            newVal = "Wireframe";
            pm = Ogre::PM_WIREFRAME;
            break;
        case Ogre::PM_WIREFRAME:
            newVal = "Points";
            pm = Ogre::PM_POINTS;
            break;
        default:
            newVal = "Solid";
            pm = Ogre::PM_SOLID;
        }

        mCamera->setPolygonMode(pm);
        mDetailsPanel->setParamValue(10, newVal);
    }
    else if(arg.key == OIS::KC_F5)   // refresh all textures
    {
        Ogre::TextureManager::getSingleton().reloadAll();
    }
    else if (arg.key == OIS::KC_SYSRQ)   // take a screenshot
    {
        mWindow->writeContentsToTimestampedFile("screenshot", ".jpg");
    }
    else if (arg.key == OIS::KC_ESCAPE)
    {
        mShutDown = true;
    }
   
    mCameraMan->injectKeyDown(arg);
    return true;
}

bool GameApplication::keyReleased( const OIS::KeyEvent &arg )
{
    mCameraMan->injectKeyUp(arg);
    return true;
}

bool GameApplication::mouseMoved( const OIS::MouseEvent &arg )
{
    if (mTrayMgr->injectMouseMove(arg)) return true;
    mCameraMan->injectMouseMove(arg);
    return true;
}

bool GameApplication::mousePressed( const OIS::MouseEvent &arg, OIS::MouseButtonID id )
{
    if (mTrayMgr->injectMouseDown(arg, id)) return true;
    mCameraMan->injectMouseDown(arg, id);
    return true;
}

bool GameApplication::mouseReleased( const OIS::MouseEvent &arg, OIS::MouseButtonID id )
{
    if (mTrayMgr->injectMouseUp(arg, id)) return true;
    mCameraMan->injectMouseUp(arg, id);
    return true;
}