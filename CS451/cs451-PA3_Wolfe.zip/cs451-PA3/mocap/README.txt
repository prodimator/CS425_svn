These mocap data in asf and amc formats are downloaded from
the motion capture database at CMU

More mocap data for subject 49 can be found on this page: 
http://mocap.cs.cmu.edu/search.php?subjectnumber=49