1. Windows 7, Visual Studio 2013
2. Given the correct command line args, run the Visual Studio debugger
3. All tasks completed
4. None were started that were not completed
5. None
6. Only known bugs are the occasional stuttering of some limbs or slight deformations in the model.